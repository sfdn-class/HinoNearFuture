/* 312_P5js_withDiv.js */
var canvas;
let playerPosX = 0;
let playerPosY = 0;
let playerPosNum = 0;
let inc = 0;
const cav_width = 1024;
const cav_height = 768;
const startX = cav_width/2;
const startY = cav_height/2;
const dice_nums = [1,2,3,4,5,6];
let msmSize = 0;
let grid_coord = new Array();
let masume_initArray = new Array();
let masume_r = 230;
let masume_g = 100;
let masume_b = 180;
let buttonAnime = 0;

let Mode = 0;
let timer = 0;




/*マス目関係*/
function masume(_posx,_posy,_size,_deg){
  push();
  translate(_posx, _posy);
  rotate(TWO_PI / 360 * _deg);
  fill(masume_r,masume_g,masume_b,200);
  stroke('#fae');
  strokeWeight(2);
  rectMode(CENTER);
  rect(0,0,_size-4,_size-4, 5);
  pop();
}

function grid_coord_init(_x, _y, _size, _rad){
  this.x = _x;
  this.y = _y;
  this.size = _size;
  this.rad = _rad;
}

if (cav_width >= cav_height) {
  msmSize = cav_height/16;
}else if (cav_height > cav_width) {
  msmSize = cav_width/16;
}

//グリッドの座標を作る
for (let i = 0; i < 16; i++) {
  for (let j = 0; j < 16; j++) {
    grid_coord.push(new grid_coord_init(j*msmSize + msmSize/2, i*msmSize + msmSize/2, msmSize, 0));
  }
}
//マスメの座標
//start
masume_initArray.push(new grid_coord_init((grid_coord[130].x+grid_coord[131].x)/2, (grid_coord[130].y+grid_coord[146].y)/2 ,msmSize*2,180));
masume_initArray.push(new grid_coord_init(grid_coord[145].x, grid_coord[145].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[161].x, grid_coord[161].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[177].x, grid_coord[177].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[193].x, grid_coord[193].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[194].x, grid_coord[194].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[195].x, grid_coord[195].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[196].x, grid_coord[196].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[212].x, grid_coord[212].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[228].x, grid_coord[228].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[229].x, grid_coord[229].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[230].x, grid_coord[230].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[231].x, grid_coord[231].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[215].x, grid_coord[215].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[216].x, grid_coord[216].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[200].x, grid_coord[200].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[201].x, grid_coord[201].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[202].x, grid_coord[202].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[203].x, grid_coord[203].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[204].x, grid_coord[204].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[205].x, grid_coord[205].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[206].x, grid_coord[206].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[190].x, grid_coord[190].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[174].x, grid_coord[174].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[158].x, grid_coord[158].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[142].x, grid_coord[142].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[141].x, grid_coord[141].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[140].x, grid_coord[140].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[139].x, grid_coord[139].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[138].x, grid_coord[138].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[154].x, grid_coord[154].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[170].x, grid_coord[170].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[169].x, grid_coord[169].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[168].x, grid_coord[168].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[167].x, grid_coord[167].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[166].x, grid_coord[166].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[165].x, grid_coord[165].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[149].x, grid_coord[149].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[133].x, grid_coord[133].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[117].x, grid_coord[117].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[101].x, grid_coord[101].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[85].x, grid_coord[85].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[84].x, grid_coord[84].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[68].x, grid_coord[68].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[52].x, grid_coord[52].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[36].x, grid_coord[36].y ,msmSize,-90));
masume_initArray.push(new grid_coord_init(grid_coord[20].x, grid_coord[20].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[21].x, grid_coord[21].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[22].x, grid_coord[22].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[23].x, grid_coord[23].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[39].x, grid_coord[39].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[55].x, grid_coord[55].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[71].x, grid_coord[71].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[72].x, grid_coord[72].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[73].x, grid_coord[73].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[74].x, grid_coord[74].y ,msmSize,0));
masume_initArray.push(new grid_coord_init(grid_coord[75].x, grid_coord[75].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[91].x, grid_coord[91].y ,msmSize,90));
masume_initArray.push(new grid_coord_init(grid_coord[107].x, grid_coord[107].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[106].x, grid_coord[106].y ,msmSize,180));
masume_initArray.push(new grid_coord_init(grid_coord[105].x, grid_coord[105].y ,msmSize,180));
//goal
masume_initArray.push(new grid_coord_init((grid_coord[103].x+grid_coord[104].x)/2, (grid_coord[103].y+grid_coord[119].y)/2 ,msmSize*2,180));



function preload() {
  img = loadImage('./images/map.png');
  player = loadImage('./images/player.png');
  dice_001 = loadImage('./images/dice_001.png');
  dice_002 = loadImage('./images/dice_002.png');
  dice_003 = loadImage('./images/dice_003.png');
  dice_004 = loadImage('./images/dice_004.png');
  dice_005 = loadImage('./images/dice_005.png');
  dice_006 = loadImage('./images/dice_006.png');
  info_01 = loadImage('./images/info/01.jpg');
  info_02 = loadImage('./images/info/02.jpg');
  info_08 = loadImage('./images/info/08.jpg');
  info_09 = loadImage('./images/info/09.jpg');
  info_15 = loadImage('./images/info/15.jpg');
  info_16 = loadImage('./images/info/16.jpg');
  info_23 = loadImage('./images/info/23.jpg');
  info_24 = loadImage('./images/info/24.jpg');
  info_30 = loadImage('./images/info/30.jpg');
  info_31 = loadImage('./images/info/31.jpg');
  info_32 = loadImage('./images/info/32.jpg');
  info_33 = loadImage('./images/info/33.jpg');
  info_34 = loadImage('./images/info/34.jpg');
  info_37 = loadImage('./images/info/37.jpg');
  info_38 = loadImage('./images/info/38.jpg');
  info_52 = loadImage('./images/info/52.jpg');
  info_53 = loadImage('./images/info/53.jpg');
  info_58 = loadImage('./images/info/58.jpg');
  info_59 = loadImage('./images/info/59.jpg');
  info_62 = loadImage('./images/info/62.jpg');

}

//setup----------------------------------------------------------------------------------//
function setup(){
    //size(640, 480);に相当する
    canvas = createCanvas(cav_width,cav_height);
    //ただしこの命令でhtml上にcanvasタグが挿入される．
    canvas.parent("P5Canvas");
    playerPosX = masume_initArray[0].x;
    playerPosY = masume_initArray[0].y;
    playerPosNum = 0;
    inc = 0;
}

//draw----------------------------------------------------------------------------------//
function draw(){
  background(240,190,20);
  imageMode(CORNER);
  image(img, 0,0, cav_height, cav_height);
  for (let i = 0; i < masume_initArray.length; i++) {
    masume(masume_initArray[i].x,masume_initArray[i].y,masume_initArray[i].size,masume_initArray[i].rad);
  }

  fill(255,0,0);
  imageMode(CENTER);
  image(player, playerPosX,playerPosY-10, 60,60);
  saikoro_draw(896,700);
  info_draw(896,20,window.rectWidth,300);
  fill(255);

  switch (Mode) {
    case 0:
      fill(0,0,0,200);
      rectMode(CORNER);
      rect(0,0,cav_width,cav_height);
      fill(255);
      textSize(80);
      textAlign(CENTER,CENTER);
      text("日野市すごろく",cav_width/2,cav_height/2 -100);
      textSize(32);
      rectMode(CENTER);
      fill('#49a9d4');
      rect(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime,textWidth('スタート') + 40,60,5);
      fill(255);
      text("スタート",cav_width/2 + buttonAnime, cav_height/2 + buttonAnime+4);
      animeButton(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime,textWidth('スタート') + 40,60);
    case 1:
      animeButton(896,700,window.rectWidth,50);
    break;
    case 2:
      animeButton(896,700,window.rectWidth,50);
      saikoro_button();
    break;
    case 3:
    fill(0,0,0,200);
    rectMode(CORNER);
    rect(0,0,cav_width,cav_height);
    fill(255);
    textSize(80);
    textAlign(CENTER,CENTER);
    text("ゲームクリア!!",cav_width/2,cav_height/2 -200);
    textSize(20);
    text("日野市役所に到着!",cav_width/2,cav_height/2 -140);
    image(info_62, cav_width/2,cav_height/2,256,256);
    textSize(32);
    rectMode(CENTER);
    fill('#49a9d4');
    rect(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime +200,textWidth('スタート画面にもどる') + 40,60,5);
    animeButton(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime+200,textWidth('スタート画面にもどる') + 40,60);
    fill(255);
    text("スタート画面にもどる",cav_width/2 + buttonAnime, cav_height/2 + buttonAnime+204);
    break;
    default:

  }
}

function mouseClicked(){
  switch (Mode) {
    case 0:
      checkButton(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime,textWidth('スタート') + 40,60,1);
    break;
    case 1:
      checkButton(896,700,window.rectWidth,50,2);
    break;
    case 3:
      checkButton(cav_width/2 + buttonAnime, cav_height/2 + buttonAnime+200,textWidth('スタート画面にもどる') + 40,60,0);
      setup();
    break;
    default:

  }

}

function info_draw(_posx,_posy,_width,_height){
  let header = '';
  let moreInfo = '';

  stroke(255,130,0);
  strokeWeight(4);
  fill(255,100);
  rect(_posx,_posy+_height/2,_width,_height,5);
  fill(255);

  if (playerPosNum == 0) {
    header = '首都大学東京';
    moreInfo = '東京都の公立大学';
    image(info_01, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 0 && playerPosNum < 8){
    header = '西平山・東平山';
    moreInfo = '浅川にかかる平山橋';
    image(info_02, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 8) {
    header = '平山城址公園駅';
    moreInfo = '京王線の駅';
    image(info_08, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 8 && playerPosNum < 15){
    header = '程久保';
    moreInfo = '七生丘陵の散策コース';
    image(info_09, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 15) {
    header = '多摩動物公園駅';
    moreInfo = '京王線と多摩モノレールの駅\n多摩動物公園がすぐそこ';
    image(info_08, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 15 && playerPosNum < 23){
    header = '百草';
    moreInfo = '百草地区の風景';
    image(info_16, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 23) {
    header = '百草園駅';
    moreInfo = '京王線の駅';
    image(info_23, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 23 && playerPosNum < 28){
    header = '落川';
    moreInfo = '落川地区の風景';
    image(info_24, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 30) {
    header = '高幡不動駅';
    moreInfo = '京王線と多摩モノレールの駅';
    image(info_30, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum >= 28 && playerPosNum < 32){
    header = '高幡不動';
    moreInfo = '高幡不動尊';
    image(info_31, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 32) {
    header = '程久保駅';
    moreInfo = '多摩モノレールの駅';
    image(info_32, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 34) {
    header = '南平駅';
    moreInfo = '多摩モノレールの駅';
    image(info_34, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 32 && playerPosNum < 37){
    header = '浅川';
    moreInfo = '浅川沿いのサイクリングロード';
    image(info_33, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 37) {
    header = '豊田駅';
    moreInfo = 'JR中央線の駅';
    image(info_37, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 37 && playerPosNum < 52){
    header = '豊田';
    moreInfo = '黒川用水のある風景';
    image(info_38, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 52) {
    header = '日野駅';
    moreInfo = 'JR中央線の駅';
    image(info_52, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 52 && playerPosNum < 58){
    header = '万願寺';
    moreInfo = '根川沿いに咲く桜';
    image(info_53, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum == 58) {
    header = '万願寺駅';
    moreInfo = '京王線の駅';
    image(info_58, _posx,_posy+140, 190,190);
  }
  else if (playerPosNum > 58 && playerPosNum < 62){
    header = '川辺堀之内';
    moreInfo = '川辺堀之内の風景';
    image(info_59, _posx,_posy+140, 190,190);
  }
  textSize(20);
  text(playerPosNum+1 + ' ' +header,_posx,_posy+30);
  noStroke();
  textSize(14);
  fill(255,130,0);
  textAlign(CENTER,TOP);
  text(moreInfo,_posx,_posy+250);

}

function saikoro_draw(_posx,_posy){
  textSize(24);
  window.label = "サイコロをふる";
  window.rectWidth = textWidth(window.label) + 40;
  rectMode(CENTER);
  fill(50,50,50,128);
  rect(_posx + 2, _posy + 2,window.rectWidth,50,5);
  fill('#49a9d4');
  rect(_posx + buttonAnime, _posy + buttonAnime,window.rectWidth,50,5);
  fill(255);
  textAlign(CENTER,CENTER);
  noStroke();
  text(window.label,_posx + buttonAnime, _posy + buttonAnime + 2);
  imageMode(CENTER);
  switch (inc) {
    case 1:
    image(dice_001, _posx, _posy-100, 128,128);
    break;
    case 2:
    image(dice_002, _posx, _posy-100, 128,128);
    break;
    case 3:
    image(dice_003, _posx, _posy-100, 128,128);
    break;
    case 4:
    image(dice_004, _posx, _posy-100, 128,128);
    break;
    case 5:
    image(dice_005, _posx, _posy-100, 128,128);
    break;
    case 6:
    image(dice_006, _posx, _posy-100, 128,128);
    break;

    default:
  }
}

function checkButton(_posx,_posy,_width,_height,_func){
  let xwl = _posx - _width/2;
  let xwh = _posx + _width/2;
  let yhl = _posy - _height/2;
  let yhh = _posy + _height/2;
  if (mouseX >  xwl && mouseX < xwh && mouseY > yhl && mouseY < yhh) {
    Mode = _func;
  }
}

function animeButton(_posx,_posy,_width,_height){
  let xwl = _posx - _width/2;
  let xwh = _posx + _width/2;
  let yhl = _posy - _height/2;
  let yhh = _posy + _height/2;
  if (mouseX >  xwl && mouseX < xwh && mouseY > yhl && mouseY < yhh) {
    if (mouseIsPressed) {
      buttonAnime = 2;
    }else{
      buttonAnime = 0;
    }
  }
}

function saikoro_button(){
    if (Mode == 2) {
      timer ++;
      if (timer >= 0 &&  timer < 40) {
        if (timer % 5 == 0) {
                inc = random(dice_nums);
        }
      }else if (timer == 40) {
        inc = random(dice_nums);
        playerPosNum += inc;
      }else if (timer > 100) {
        if (playerPosNum > 0 && playerPosNum < (masume_initArray.length - 1)) {
          playerPosX = masume_initArray[playerPosNum].x;
          playerPosY = masume_initArray[playerPosNum].y;
          Mode = 1;
          timer = 0;
        }
        else if (playerPosNum == (masume_initArray.length - 1)) {
          playerPosX = masume_initArray[playerPosNum].x;
          playerPosY = masume_initArray[playerPosNum].y;
          Mode = 3;
          timer = 0;
        }
        else if (playerPosNum > (masume_initArray.length - 1)) {
          let subt = playerPosNum - (masume_initArray.length - 1);
          playerPosNum = (masume_initArray.length - 1) - subt;
          playerPosX = masume_initArray[playerPosNum].x;
          playerPosY = masume_initArray[playerPosNum].y;
          Mode = 1;
          timer = 0;
        }
      }
  }
}
